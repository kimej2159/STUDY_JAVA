package miniproject;

public class No3_carculatormain {
	
	public static void main(String[] args)		//사칙 연산하는 메소드
	{
		
		No3_carculator.printadd(5, 3);	
		No3_carculator.printsub(9, 7);
		No3_carculator.printmulti(8, 4);
		No3_carculator.printdiv(12, 6);
	
	}
	
}
