package miniproject;

public class No2_Star {
	
	public static void main(String[] args) {
		
	
		for(int i = 5; i > 0; i--)
		{
			for(int no1 = i; no1 > 0; no1--)
			{ 
				System.out.print("*"); 
			}
			System.out.println();
		}
		
	}
}
